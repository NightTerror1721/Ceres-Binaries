#pragma once

#include "stddef.h"
#include "stdarg.h"

// Console I/O over the terminal device (see ceres/terminal.h), formatted input and output, and streams
// (FILE) over the terminal, over memory, and over files on the disk (CeresFS, ceres/fs.h). A disk must
// carry a CeresFS before fopen() can work: call fs_format() once, or fs_mount() for a disk that has one;
// otherwise fopen() fails with ENODEV.

#define EOF          (-1)
#define BUFSIZ       512
#define FILENAME_MAX 64
#define FOPEN_MAX    8
#define SEEK_SET     0
#define SEEK_CUR     1
#define SEEK_END     2
#define _IOFBF       0
#define _IOLBF       1
#define _IONBF       2

struct __file;
typedef struct __file FILE;
typedef int fpos_t;

// Pointer VARIABLES, not objects: an `extern struct-of-unknown-size x;` cannot be declared in this subset.
extern FILE* stdin;
extern FILE* stdout;
extern FILE* stderr;

// ---- characters and strings on the console ----
int  putchar(int c);                    // write one byte; returns it
int  getchar(void);                     // WAITS for a byte and returns it; the same stream as fgetc(stdin)
int  getchar_nb(void);                  // the byte if one is buffered, else -1: the loop-friendly form
int  putstr(const char* s);             // write a NUL-terminated string; returns its length
int  puts(const char* s);               // putstr + newline

// getchar() returns EOF, and feof(stdin) becomes true, once the input has ended: a pipe that ran dry, or
// Ctrl-Z / Ctrl-D at a console. Until then it waits. Use getchar_nb() when the program has other work to do.

// Declared here as well as in stdlib.h: a translation unit that declares exit() ends main by calling it, so
// that returning n from main is exit(n) - the atexit handlers run and open files are flushed.
void exit(int status) __attribute__((__noreturn__));

// ---- numbers, without the format engine (small and fast) ----
int  putint(int v);                     // decimal, with sign
int  putuint(unsigned int v);           // decimal, unsigned
int  puthex(unsigned int v);            // "0x" + minimal lowercase hex digits
int  putbin(unsigned int v, int bits);  // `bits` binary digits, most significant first
int  putfloat(float f, int decimals);   // like "%.*f": sign, integer, '.', `decimals` digits

// ---- formatted output (src/format.c) ----
// %d %i %u %o %x %X %b %c %s %p %n %f %F %e %E %g %G %%, with flags "- + space # 0", width and
// precision (a number or *), and the length modifiers hh h l ll z t j q (ll, j and q take a 64-bit
// argument; l, z and t are 32 bits here). Returns the number of characters that were (or, for
// snprintf, would have been) produced. The format attribute has ceresc check a literal format
// against the arguments (W3005, W3006): on this machine a %lld given an int, or a %d given a
// long long, shifts every argument after it.
int  printf(const char* fmt, ...) __attribute__((__format__(__printf__, 1, 2)));
int  vprintf(const char* fmt, va_list ap) __attribute__((__format__(__printf__, 1, 0)));
int  fprintf(FILE* f, const char* fmt, ...) __attribute__((__format__(__printf__, 2, 3)));
int  vfprintf(FILE* f, const char* fmt, va_list ap) __attribute__((__format__(__printf__, 2, 0)));
int  sprintf(char* buf, const char* fmt, ...) __attribute__((__format__(__printf__, 2, 3)));
int  vsprintf(char* buf, const char* fmt, va_list ap) __attribute__((__format__(__printf__, 2, 0)));
int  snprintf(char* buf, size_t n, const char* fmt, ...) __attribute__((__format__(__printf__, 3, 4)));   // always NUL-terminates when n > 0
int  vsnprintf(char* buf, size_t n, const char* fmt, va_list ap) __attribute__((__format__(__printf__, 3, 0)));

// ---- formatted input (src/scanf.c) ----
// %d %i %u %x %X %o %c %s %f %e %g %[set] %p %n %%, with a width, `*` to skip a conversion and the length
// modifiers hh h l ll z t j q L (%f stores a float, %lf and %Lf a double; printf's %f takes a double, a float
// argument arriving promoted). Returns how many conversions stored a value, or EOF when the input ended before
// the first one. Whitespace in the format matches any run of whitespace; any other character must match exactly,
// and the first mismatch stops the scan. Under -fshort-double, where `double` is a float, %lf and %Lf store a
// float: these names are then the variants that know it. (printf needs none: a float passed through `...`
// travels as a binary64 either way.)
#ifdef __CERES_SHORT_DOUBLE__
#define scanf   __scanf_sd
#define vscanf  __vscanf_sd
#define fscanf  __fscanf_sd
#define vfscanf __vfscanf_sd
#define sscanf  __sscanf_sd
#define vsscanf __vsscanf_sd
#endif
int  scanf(const char* fmt, ...) __attribute__((__format__(__scanf__, 1, 2)));
int  vscanf(const char* fmt, va_list ap) __attribute__((__format__(__scanf__, 1, 0)));
int  fscanf(FILE* f, const char* fmt, ...) __attribute__((__format__(__scanf__, 2, 3)));
int  vfscanf(FILE* f, const char* fmt, va_list ap) __attribute__((__format__(__scanf__, 2, 0)));
int  sscanf(const char* s, const char* fmt, ...) __attribute__((__format__(__scanf__, 2, 3)));
int  vsscanf(const char* s, const char* fmt, va_list ap) __attribute__((__format__(__scanf__, 2, 0)));

// ---- streams (src/file.c) ----
// stdout and stderr are unbuffered unless setvbuf says otherwise, so by default nothing is lost when the program
// stops and printf/fprintf/putchar always come out in order. stderr is the terminal's error stream: the host's
// stderr under `ceres run`, kept apart from what the program prints. stdin waits for each byte and has one
// character of pushback. A file is fully buffered (BUFSIZ bytes): a byte at a time goes through the buffer, a large
// fread/fwrite goes straight through, and what is held back is written by fflush, fclose, a seek, and exit().
FILE* fopen(const char* path, const char* mode);          // "r" "w" "a", with "+" and/or "b"; NULL with errno set (ENOENT, ENODEV, ENOSPC, EMFILE, EBUSY...)
                                                           // "host:levels/1.txt" is a host file (ceres run --host-dir, ceres/hostfs.h)
FILE* freopen(const char* path, const char* mode, FILE* f);   // closes f and opens path in its place - stdin, stdout, stderr too
                                                           // ("host:log.txt"); "term:" puts a standard stream back on the terminal
FILE* fmemopen(void* buf, size_t size, const char* mode);     // a stream over `buf`; it never grows
int   fclose(FILE* f);
int   fflush(FILE* f);                                     // writes out what f holds back; NULL: every stream, then the disk
int   setvbuf(FILE* f, char* buf, int mode, size_t size);  // _IOFBF, _IOLBF or _IONBF; buf NULL: allocated (size, or BUFSIZ)
void  setbuf(FILE* f, char* buf);
FILE* tmpfile(void);                                       // a "w+" file that is removed when it is closed
int   remove(const char* path);                            // deletes a disk file; -1 with errno set
int   rename(const char* from, const char* to);            // -1 with errno set (EEXIST when the new name is taken)

size_t fread(void* buf, size_t size, size_t n, FILE* f);
size_t fwrite(const void* buf, size_t size, size_t n, FILE* f);
int   fgetc(FILE* f);
int   getc(FILE* f);
int   fputc(int c, FILE* f);
int   putc(int c, FILE* f);
int   ungetc(int c, FILE* f);                              // one character of pushback
char* fgets(char* buf, int n, FILE* f);                    // through the newline, at most n-1 characters
int   fputs(const char* s, FILE* f);
int   getline(char** line, size_t* cap, FILE* f);          // POSIX: a malloc'd, growing buffer; -1 at EOF

int   fseek(FILE* f, int offset, int whence);              // files and memory streams (ESPIPE on the terminal)
int   ftell(FILE* f);
void  rewind(FILE* f);
int   fgetpos(FILE* f, fpos_t* p);
int   fsetpos(FILE* f, const fpos_t* p);
int   feof(FILE* f);
int   ferror(FILE* f);
void  clearerr(FILE* f);
void  perror(const char* msg);                             // "msg: <strerror(errno)>" on stderr
