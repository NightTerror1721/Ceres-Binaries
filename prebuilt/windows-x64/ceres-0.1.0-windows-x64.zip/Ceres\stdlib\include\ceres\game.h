#pragma once

// A fixed-step game loop: input -> logic -> drawing -> present -> wait for the next frame.
//
//   struct game g;
//   game_init(&g, 200000);                  // a frame is 200000 CPU cycles
//   while (g.running) {
//       game_frame_begin(&g);               // input_update() and the start mark
//       ...update, draw, gfx_present()...
//       game_frame_end(&g);                 // wait out the rest of the frame
//   }
//   // or: game_run(&g, update, draw, ctx);
//
// TIME. The machine's clock is its own: CPU cycles (ceres/timer.h). By default a frame is a BUDGET OF
// CYCLES and waiting is a spin on timer_ticks(): the same program does the same thing on every run, which is
// what a test wants, and the same game has more room per frame at -O2 than at -O0.
//
// A game on the screen keeps the screen's time: game_pace_vblank(&g, 1) ends each frame at the next vertical
// blank (ceres/video.h), 60 a second - or every n blanks with n. It is the machine's own clock too, so the game
// does the same on every run. (gfx_present() and fb_present() already wait for the blank: a game drawn with them
// is paced by the screen with any setting here.)
//
// For a game that must run at a steady speed there are two more ways, and in both a frame lasts `ms` milliseconds
// of the machine's time from its start - its own work counts, and a frame that runs late is not made up for.
// The host keeps that time in step with the wall clock (`ceres run --speed realtime`, the default with a window):
//   game_pace_ms(&g, 16)     sleeps: halts with the timer's alarm at the frame's end (timer_wait_until_ns64), so
//                            the host is not kept busy. Needs no handler and no module;
//   game_pace_real(&g, 16)   spins on the nanosecond clock instead: the host is kept busy, and the frame ends
//                            to the clock's step rather than the host's sleep's. Both are about 60 frames a second.

#include "../stddef.h"
#include "../stdint.h"

struct game
{
    int running;                       // cleared by game_quit
    unsigned int frame;                // frames completed
    unsigned int ticks_per_frame;      // the cycle budget of a frame
    unsigned int frame_start;          // timer_ticks() when the frame began
    unsigned int work_last;            // cycles the last frame spent before waiting
    unsigned int wait_ms;              // 0: pace by cycles; otherwise the frame period in milliseconds (or in blanks, by vblank)
    unsigned int frame_start_vblank;   // video_frame() when the frame began
    uint64_t frame_start_ns;           // timer_nanos64() when the frame began
    void (*wait)(struct game* g);      // what game_frame_end runs to pass the rest of the frame; 0 spins on the budget
};

typedef void (*game_fn)(struct game* g, void* ctx);

void game_init(struct game* g, unsigned int ticks_per_frame);   // also input_init()
void game_quit(struct game* g);
void game_frame_begin(struct game* g);      // input_update(), and the mark work is measured from
void game_frame_end(struct game* g);        // counts the frame and waits out the rest of it
int  game_over_budget(const struct game* g);   // 1 when the last frame spent more than its budget (meaningful when pacing by cycles)
void game_run(struct game* g, game_fn update, game_fn draw, void* ctx);   // until game_quit

void game_pace_real(struct game* g, unsigned int ms);   // time pacing by spinning on the nanosecond clock
void game_pace_ms(struct game* g, unsigned int ms);     // time pacing by sleeping; ms is at least 1
void game_pace_vblank(struct game* g, unsigned int frames);   // a frame ends at the `frames`th vertical blank from its start (at least 1)
